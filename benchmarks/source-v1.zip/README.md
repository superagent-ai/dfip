# DFIP

**Decision-focused inference on Modal.** Run open decision models through a common
Python client, using validated model-specific acceleration. Python/PyTorch handles
model execution; Triton accelerates Liquid's candidate projection; CUDA graphs
reduce launch overhead for eligible repeated requests.

Model weights, datasets, and GPU dependencies stay on Modal. The local package
contains only the client and deployment source. DFIP currently supports text
requests with `choice`, `noul` (yes/no), and `score` questions.

## Quick start

Requires Python 3.10+, a Modal account with GPU access, and access to your chosen
Hugging Face checkpoint. Start with Liquid or Julia; the 27B models use a B200.

```sh
git clone https://github.com/superagent-ai/dfip.git
cd dfip
python -m venv .venv
source .venv/bin/activate
python -m pip install -e .
modal setup
dfip setup --model liquid
dfip predict --model liquid --input examples/request.json
```

`setup` downloads the pinned model into your Modal volume and deploys the private
`dfip-inference` app in your account. Only the selected model is downloaded. Other
classes become usable after preparing their checkpoint. No API keys belong in
request files. Predictions use your authenticated Modal SDK credentials.

For a gated model, first accept its Hugging Face terms and create a Modal secret
named `dfip-hf` with an `HF_TOKEN` key in the Modal dashboard. Then:

```sh
export DFIP_HF_SECRET=dfip-hf
dfip prepare --model security
dfip predict --model security --input examples/request.json
```

There is no public HTTP endpoint in this release. Containers scale to zero after
60 seconds of inactivity. A first request includes model loading and graph setup;
Security-One also starts its SGLang server. Modal bills preparation, execution,
and the idle window according to your account's rates.

## Python client

```python
from dfip import Client

client = Client("liquid")
result = client.predict([
    {
        "state": "I was charged twice. Please refund the duplicate payment.",
        "questions": {
            "team": {
                "type": "choice",
                "instructions": "Which team should handle this request?",
                "criteria": {
                    "billing": "Payments and refunds",
                    "technical": "Software bugs",
                },
            },
        },
    },
])
print(result[0]["answers"]["team"]["choice"])
```

`await client.predict_async(records)` supports asynchronous calls.
`client.diagnostics()` reports the chosen optimization and graph activity.
Outputs retain the released model's `answers` format, including probabilities
and typed values; model-specific extra fields may differ. Score criteria are an
ordered list of descriptions; `noul` criteria optionally describe `false` and
`true`. See [the request example](examples/request.json).

## Models

| Alias | Hugging Face checkpoint | Default GPU | Serving path |
| --- | --- | --- | --- |
| `julia` | [SupersonicLabs/Julia-1](https://huggingface.co/SupersonicLabs/Julia-1) | L40S | Native FastEngine + CUDA graphs |
| `liquid` | [LiquidAI/d1-3B](https://huggingface.co/LiquidAI/d1-3B) | L40S | Candidate projection + eligible CUDA graphs |
| `clef` | [Cloudflare/clef-flash](https://huggingface.co/Cloudflare/clef-flash) | L40S | Native API + eligible CUDA graphs |
| `decider` | [perplexity-ai/pplx-decider-v1.1-27b](https://huggingface.co/perplexity-ai/pplx-decider-v1.1-27b) | B200 | Native API + short single-decision graphs |
| `security` | [superagent-ai/security-one-27b](https://huggingface.co/superagent-ai/security-one-27b) | B200 | Native SGLang 0.5.19 |

`dfip models` lists immutable checkpoint revisions. `dfip prepare --model all`
downloads all five checkpoints remotely. HF IDs also work wherever aliases do.
The [decision-model tag](https://huggingface.co/models?other=decision-model) is a
source of candidates for future adapters; arbitrary tagged models are not
compatible automatically. Model weights and downloaded upstream code retain
their own licenses. Pinned upstream custom Python code executes in the remote
container when required by the released model.

## Configuration

| Environment variable | Default | Purpose |
| --- | --- | --- |
| `DFIP_APP` | `dfip-inference` | Modal deployment name |
| `DFIP_VOLUME` | `dfip-models-v1` | Persistent checkpoint and cache volume |
| `DFIP_HF_SECRET` | unset | Optional Modal secret containing `HF_TOKEN` |

Set these consistently for prepare, deploy, evaluation, and inference. For
example, use `DFIP_APP=my-dfip DFIP_VOLUME=my-dfip-models dfip setup --model julia`.
Use `Client("julia", app_name="my-dfip", environment_name="staging")` to select a
deployment explicitly. Modal's own environment selection applies to deployment.

## Benchmarks and verification

Measured resident short binary decision calls on one GPU:

| Model | Native p50 | Selected serving path p50 | Paired speedup |
| --- | ---: | ---: | ---: |
| Julia, L40S | 14.85 ms | 2.25 ms | 6.60× |
| Liquid, L40S | 20.98 ms | 10.97 ms | 1.91× |
| Clef, L40S | 46.31 ms | 32.16 ms | 1.44× |
| Decider, B200 | 115.08 ms | 35.02 ms | 3.29× |
| Security-One, B200 | 47.91 ms | 47.91 ms | 1.00× |

These are paired warm compute measurements, including encoding and probability
readout, with 100 samples per workload. Security includes local HTTP scheduling.
They exclude client network latency, cold starts, capture setup, and idle billing.
GPU cost estimates are not total application cost. Decider's native latency varied
across runs. Clef/Decider use the upstream convolution fallback without
`causal-conv1d`; these are not optimized serving ceilings.

The selected paths preserved argmax across 2,000 public dataset questions; the
four in-process adapters also passed 128 varied single-question checks each.
Clef showed up to 0.001 probability drift in those extra checks. The corpus is
not a security-specific quality benchmark; training overlap is unknown.
[Detailed report](docs/dfip-report.html), [summary CSV](docs/dfip-benchmarks.csv),
and [raw results](docs/dfip-benchmarks.json) contain scope and rejected experiments.

```sh
# Quick GPU/kernel check, downloaded weights remain on Modal.
dfip smoke --model liquid --output liquid-smoke.json

# Full 400-case fidelity + 128 varied single-question checks.
dfip validate --model liquid --output liquid-validation.json

# Paired released-native versus deployed-production path.
dfip benchmark --model liquid --quality 400 --repetitions 100 --output liquid-benchmark.json
```

All five models support `smoke` and `benchmark`. Security's benchmark measures
its selected native SGLang path; its head ablation is a separate experiment:

```sh
modal run -m dfip.cloud.sglang_benchmark --quality 400 --repetitions 100 --output security-head-ablation
```

`validate` covers the four in-process adapters. Benchmark and validation result
JSON is returned locally; model weights and the dataset stay in the remote volume.

## Operational limits

Graph caches store computation, never predictions. Calls within one engine are
serialized because CUDA graph input buffers are mutable. A shape becomes eligible
after three matching calls; the graph cache holds four shapes and falls back to
native inference for unsupported captures. Liquid updates the answer-token union
and invalidates graphs when new candidate tokens appear.

Liquid/Clef/Decider graph capture is limited to sequences of at most 512 tokens.
Clef/Decider additionally require a single-row forward. Decider multi-question
and batched requests use native execution because padded hybrid graphs failed
stress validation. Julia preserves its strict 8,192-token encoding limit.
Security-One supports at most 8,192 tokens and 255 options, without truncation.
Other adapters retain the released APIs' context constraints.

Experimental RMSNorm replacements, Julia marker-only projection, and Security
head patches are excluded from serving defaults. Some changed probabilities or
decisions; see the report before using them. Custom projection retains the
original model weights, so it reduces readout computation rather than model size.

## Development

```sh
python -m pip install -e '.[dev]'
pytest
ruff check src tests
```

CI checks packaging, local client behavior, and imports without GPU libraries on
Python 3.10 and 3.12. GPU tests run explicitly on Modal and incur cloud usage.
See [CONTRIBUTING.md](CONTRIBUTING.md) for adding a model safely. DFIP source is
MIT licensed; checkpoint licenses and dataset terms apply independently.
